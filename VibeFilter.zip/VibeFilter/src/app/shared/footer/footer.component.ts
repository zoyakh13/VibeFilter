import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.scss'
})
export class FooterComponent {
  currentYear = new Date().getFullYear();
  
  onNewsletterSubscribe(email: string) {
    if (email && this.isValidEmail(email)) {
      // Here you would typically call a service to handle newsletter subscription
      console.log('Newsletter subscription for:', email);
      alert('Thank you for subscribing to our newsletter!');
    } else {
      alert('Please enter a valid email address.');
    }
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  onSocialLinkClick(platform: string) {
    // Handle social media link clicks
    console.log(`Clicked on ${platform} social link`);
    // You can add tracking or navigation logic here
  }

  onFooterLinkClick(link: string) {
    // Handle footer link clicks
    console.log(`Clicked on footer link: ${link}`);
    // You can add navigation logic here
  }
}
