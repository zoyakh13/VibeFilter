import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Product, Comment, MoodEmoji } from '../../models/product.interface';
import { PRODUCTS_DATA } from '../../config/products-data.config';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private productsSubject = new BehaviorSubject<Product[]>([]);
  public products$ = this.productsSubject.asObservable();

  private moodEmojiMap: MoodEmoji = {
    "Appreciable": "😊",
    "Improvement": "🤔",
    "Neutral": "😐",
    "Abusive": "😡"
  };

  private productsData: Product[] = PRODUCTS_DATA;

  constructor() {
    this.loadProducts();
  }

  private loadProducts(): void {
    // Add random users and dates to comments
    const userNames = [
      "Amit", "Priya", "John", "Sara", "Ravi", "Emily", "Raj", "Nina", "Alex", "Meera", "Sam", "Kiran"
    ];
    const dates = [
      "2024-06-01", "2024-06-02", "2024-06-03", "2024-06-04", "2024-06-05", "2024-06-06",
      "2024-06-07", "2024-06-08", "2024-06-09", "2024-06-10", "2024-06-11", "2024-06-12"
    ];

    // Enhance comments with user and date
    this.productsData.forEach(product => {
      product.comments.forEach((comment, index) => {
        comment.user = userNames[index % userNames.length];
        comment.date = dates[index % dates.length];
      });
    });

    this.productsSubject.next(this.productsData);
  }

  getProducts(): Observable<Product[]> {
    return this.products$;
  }

  getProduct(index: number): Product | undefined {
    return this.productsData[index];
  }

  getMoodEmoji(mood: string): string {
    return this.moodEmojiMap[mood] || "🙂";
  }

  getUniqueShortTitles(productIndex: number, mood: string): string[] {
    if (!this.productsData[productIndex]) return [];
    
    const comments = this.productsData[productIndex].comments;
    const filteredComments = comments.filter(c => c.mood === mood);
    return Array.from(new Set(filteredComments.map(c => c.short_title)));
  }

  getCommentsByFilter(productIndex: number, mood: string, shortTitle: string): Comment[] {
    if (!this.productsData[productIndex]) return [];
    
    // Simply return the actual comments that match the filter without duplication
    return this.productsData[productIndex].comments
      .filter(c => c.mood === mood && c.short_title === shortTitle);
  }

  getUniqueMoods(productIndex: number): string[] {
    if (!this.productsData[productIndex]) return [];
    
    const comments = this.productsData[productIndex].comments;
    return Array.from(new Set(comments.map(c => c.mood)));
  }

  getAverageMoodEmoji(product: Product): string {
    const moodCounts: { [key: string]: number } = {};
    product.comments.forEach(c => {
      moodCounts[c.mood] = (moodCounts[c.mood] || 0) + 1;
    });
    
    let maxMood = '';
    let maxCount = 0;
    Object.entries(moodCounts).forEach(([mood, count]) => {
      if (count > maxCount) {
        maxMood = mood;
        maxCount = count;
      }
    });
    
    return this.getMoodEmoji(maxMood);
  }
}
