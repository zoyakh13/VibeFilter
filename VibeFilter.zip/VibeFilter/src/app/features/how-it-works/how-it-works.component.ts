import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-how-it-works',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './how-it-works.component.html',
  styleUrl: './how-it-works.component.scss'
})
export class HowItWorksComponent {
  @Input() showModal: boolean = false;
  @Output() closeModal = new EventEmitter<void>();
  @Output() startExploring = new EventEmitter<void>();

  // Professional How It Works data
  howItWorksSteps = [
    {
      step: 1,
      icon: '🎯',
      title: 'Browse Curated Products',
      description: 'Discover our carefully selected collection of products, each backed by authentic user experiences and emotional feedback.',
      details: 'Our AI-powered curation system ensures you see only the most relevant and highly-rated products.'
    },
    {
      step: 2,
      icon: '💭',
      title: 'Read Emotional Reviews',
      description: 'Get insights beyond traditional ratings. Understand how products make real people feel through authentic emotional reviews.',
      details: 'Our emotion-based review system captures genuine user sentiments and moods.'
    },
    {
      step: 3,
      icon: '🎭',
      title: 'Filter by Mood & Vibe',
      description: 'Use our advanced filtering system to find products that match your current emotional state and desired experience.',
      details: 'Filter by happiness, excitement, satisfaction, relaxation, and more emotional categories.'
    },
    {
      step: 4,
      icon: '✨',
      title: 'Make Confident Decisions',
      description: 'Purchase with confidence knowing that others with similar emotional preferences have had positive experiences.',
      details: 'Our recommendation engine matches your emotional profile with compatible products.'
    }
  ];

  closeHowItWorksModal(): void {
    this.closeModal.emit();
    // Remove body class to restore scrolling
    document.body.classList.remove('modal-open');
  }

  // Close modal when clicking outside
  onModalBackdropClick(event: Event): void {
    if (event.target === event.currentTarget) {
      this.closeHowItWorksModal();
    }
  }

  onStartExploring(): void {
    this.startExploring.emit();
    this.closeHowItWorksModal();
  }
}
