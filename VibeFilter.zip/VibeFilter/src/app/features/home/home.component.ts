import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../core/services/api.service';
import { Product, Comment } from '../../models/product.interface';
import { HowItWorksComponent } from '../how-it-works/how-it-works.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule, HowItWorksComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent implements OnInit {
  
  products: Product[] = [];
  selectedProductIndex: string = '';
  selectedMood: string = '';
  selectedShortTitle: string = '';
  
  uniqueMoods: string[] = [];
  uniqueShortTitles: string[] = [];
  filteredComments: Comment[] = [];
  selectedProduct: Product | null = null;

  // Creative exploration functionality
  isExploring: boolean = false;
  showSparkles: boolean = false;
  exploringText: string = 'Start Exploring Products';
  
  // Professional modal functionality
  showHowItWorksModal: boolean = false;

  // Filter enhancement properties
  isLoadingProducts: boolean = false;
  isLoadingMoods: boolean = false;
  isLoadingTitles: boolean = false;
  
  private exploringTexts = [
    'Start Exploring Products',
    '🎉 Let\'s Explore!',
    '🚀 Adventure Awaits!',
    '🌟 Find Your Vibe!',
    '💫 Discover Magic!',
    '🎊 Ready to Explore?'
  ];

  // This is a comment to trigger refresh
  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.productService.getProducts().subscribe(products => {
      this.products = products;
      // Initialize unique moods from all products for overall stats
      this.uniqueMoods = this.getAllUniqueMoods();
    });
  }

  // Helper method to get all unique moods across all products
  private getAllUniqueMoods(): string[] {
    const allMoods = new Set<string>();
    this.products.forEach(product => {
      product.comments.forEach(comment => {
        allMoods.add(comment.mood);
      });
    });
    return Array.from(allMoods);
  }

  onProductChange(): void {
    // Reset dependent dropdowns
    this.selectedMood = '';
    this.selectedShortTitle = '';
    this.filteredComments = [];
    this.uniqueShortTitles = [];
    
    if (this.selectedProductIndex !== '') {
      const index = parseInt(this.selectedProductIndex);
      this.selectedProduct = this.productService.getProduct(index) || null;
      // Get unique moods for this specific product
      this.uniqueMoods = this.productService.getUniqueMoods(index);
    } else {
      this.selectedProduct = null;
      // Reset to all unique moods when no product is selected
      this.uniqueMoods = this.getAllUniqueMoods();
    }
  }

  onMoodChange(): void {
    this.selectedShortTitle = '';
    this.filteredComments = [];
    
    if (this.selectedProductIndex !== '' && this.selectedMood) {
      const index = parseInt(this.selectedProductIndex);
      this.uniqueShortTitles = this.productService.getUniqueShortTitles(index, this.selectedMood);
    } else {
      this.uniqueShortTitles = [];
    }
  }

  onShortTitleChange(): void {
    if (this.selectedProductIndex !== '' && this.selectedMood && this.selectedShortTitle) {
      const index = parseInt(this.selectedProductIndex);
      this.filteredComments = this.productService.getCommentsByFilter(index, this.selectedMood, this.selectedShortTitle);
    } else {
      this.filteredComments = [];
    }
  }

  getMoodEmoji(mood: string): string {
    return this.productService.getMoodEmoji(mood);
  }

  getAverageMoodEmoji(product: Product): string {
    return this.productService.getAverageMoodEmoji(product);
  }

  // Helper method to get total comments count for display
  getCommentsCount(): number {
    return this.filteredComments.length;
  }

  // Helper method to get all short titles for a mood (for debugging/info)
  getShortTitlesForMood(mood: string): string[] {
    if (this.selectedProductIndex === '') return [];
    const index = parseInt(this.selectedProductIndex);
    return this.productService.getUniqueShortTitles(index, mood);
  }

  // Image error handling method  
  onImageError(event: Event): void {
    const target = event.target as HTMLImageElement;
    console.warn('Image failed to load:', target.src);
    target.classList.add('image-error');
    // Could also set a fallback image here if needed
  }

  // Helper method to check if image is a data URI (safe from corporate blocking)
  isDataUri(imageUrl: string): boolean {
    return imageUrl.startsWith('data:');
  }

  // Additional methods for the new UI functionality
  
  // Enhanced filter methods for creative UI
  hasActiveFilters(): boolean {
    return this.selectedProductIndex !== '' || this.selectedMood !== '' || this.selectedShortTitle !== '';
  }

  clearAllFilters(): void {
    this.selectedProductIndex = '';
    this.selectedMood = '';
    this.selectedShortTitle = '';
    this.selectedProduct = null;
    this.filteredComments = [];
    this.uniqueShortTitles = [];
    // Reset to all unique moods when no filters are active
    this.uniqueMoods = this.getAllUniqueMoods();
  }
  
  // Helper method to get star array for rating display
  getStarArray(rating: number): number[] {
    const filledStars = Math.floor(rating);
    return Array(filledStars).fill(0);
  }

  // Helper method to get empty star array for rating display  
  getEmptyStarArray(rating: number): number[] {
    const filledStars = Math.floor(rating);
    const emptyStars = 5 - filledStars;
    return Array(emptyStars).fill(0);
  }

  // Method to select a product from the grid
  selectProduct(index: number): void {
    this.selectedProductIndex = index.toString();
    this.onProductChange();
  }

  viewProductDetails(index: number): void {
    this.selectProduct(index);
    // Scroll to the product details section
    setTimeout(() => {
      const detailsElement = document.querySelector('.product-details-section');
      if (detailsElement) {
        detailsElement.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  }
  
  viewProductReviews(index: number): void {
    this.selectProduct(index);
    // Show all reviews for this product by setting up default filters
    this.selectedMood = '';
    this.selectedShortTitle = '';
    this.onMoodChange();
    
    // Get all comments for this product
    const product = this.products[index];
    if (product) {
      this.filteredComments = product.comments;
    }
    
    // Scroll to reviews section
    setTimeout(() => {
      const reviewsElement = document.querySelector('.reviews-section');
      if (reviewsElement) {
        reviewsElement.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  }
  
  clearSelection(): void {
    this.selectedProduct = null;
    this.selectedProductIndex = '';
    this.selectedMood = '';
    this.selectedShortTitle = '';
    this.filteredComments = [];
    this.uniqueShortTitles = [];
    this.uniqueMoods = this.getAllUniqueMoods();
  }

  // Creative exploration method with multiple effects
  startExploring(): void {
    if (this.isExploring) return; // Prevent multiple clicks
    
    this.isExploring = true;
    this.showSparkles = true;
    
    // Fun text animation sequence
    let textIndex = 1;
    const textInterval = setInterval(() => {
      this.exploringText = this.exploringTexts[textIndex];
      textIndex = (textIndex + 1) % this.exploringTexts.length;
      
      if (textIndex === 0) {
        clearInterval(textInterval);
        // Reset to original text after animation
        setTimeout(() => {
          this.exploringText = this.exploringTexts[0];
        }, 500);
      }
    }, 300);
    
    // Shuffle products for visual effect
    setTimeout(() => {
      this.shuffleProductsAnimation();
    }, 800);
    
    // Smooth scroll to products section
    setTimeout(() => {
      this.scrollToProducts();
    }, 1500);
    
    // Show random product selection
    setTimeout(() => {
      this.highlightRandomProduct();
    }, 2000);
    
    // Reset exploring state
    setTimeout(() => {
      this.isExploring = false;
      this.showSparkles = false;
    }, 3000);
  }
  
  // Smooth scroll to products section with easing
  private scrollToProducts(): void {
    const productsSection = document.querySelector('.products-section');
    if (productsSection) {
      productsSection.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
      
      // Add temporary glow effect to the section
      productsSection.classList.add('section-glow');
      setTimeout(() => {
        productsSection.classList.remove('section-glow');
      }, 2000);
    }
  }
  
  // Animate product cards in sequence
  private shuffleProductsAnimation(): void {
    const productCards = document.querySelectorAll('.product-grid-card');
    
    productCards.forEach((card, index) => {
      setTimeout(() => {
        card.classList.add('shuffle-animation');
        setTimeout(() => {
          card.classList.remove('shuffle-animation');
        }, 600);
      }, index * 100);
    });
  }
  
  // Highlight a random product to catch attention
  private highlightRandomProduct(): void {
    if (this.products.length === 0) return;
    
    const randomIndex = Math.floor(Math.random() * this.products.length);
    const randomCard = document.querySelectorAll('.product-grid-card')[randomIndex];
    
    if (randomCard) {
      randomCard.classList.add('product-highlight');
      
      // Auto-select this product after highlight
      setTimeout(() => {
        this.selectedProductIndex = randomIndex.toString();
        this.onProductChange();
        randomCard.classList.remove('product-highlight');
      }, 1500);
    }
  }
  
  // Professional How It Works modal functionality
  showHowItWorks(): void {
    this.showHowItWorksModal = true;
    // Add body class to prevent background scrolling
    document.body.classList.add('modal-open');
  }
  
  closeHowItWorksModal(): void {
    this.showHowItWorksModal = false;
    // Remove body class to restore scrolling
    document.body.classList.remove('modal-open');
  }

  getProductEmoji(product: Product): string {
    // Return an emoji based on the product's average rating or type
    const rating = product.rating;
    if (rating >= 4.5) return '⭐';
    if (rating >= 4.0) return '👍';
    if (rating >= 3.5) return '👌';
    if (rating >= 3.0) return '🤔';
    return '👎';
  }

  getMoodCount(mood: string): number {
    if (this.selectedProductIndex !== '') {
      const index = parseInt(this.selectedProductIndex);
      const product = this.products[index];
      if (product) {
        return product.comments.filter(comment => comment.mood === mood).length;
      }
    } else {
      // Count across all products when no specific product is selected
      return this.products.reduce((count, product) => {
        return count + product.comments.filter(comment => comment.mood === mood).length;
      }, 0);
    }
    return 0;
  }

  getShortTitleEmoji(title: string): string {
    // Return emoji based on the sentiment of the short title
    const lowerTitle = title.toLowerCase();
    
    if (lowerTitle.includes('amazing') || lowerTitle.includes('excellent') || lowerTitle.includes('outstanding')) return '🌟';
    if (lowerTitle.includes('great') || lowerTitle.includes('perfect') || lowerTitle.includes('love')) return '💚';
    if (lowerTitle.includes('good') || lowerTitle.includes('nice') || lowerTitle.includes('helpful')) return '👍';
    if (lowerTitle.includes('issue') || lowerTitle.includes('problem') || lowerTitle.includes('concern')) return '⚠️';
    if (lowerTitle.includes('bad') || lowerTitle.includes('poor') || lowerTitle.includes('terrible')) return '👎';
    if (lowerTitle.includes('slow') || lowerTitle.includes('expensive') || lowerTitle.includes('heavy')) return '🐌';
    if (lowerTitle.includes('fast') || lowerTitle.includes('quick') || lowerTitle.includes('convenient')) return '⚡';
    if (lowerTitle.includes('comfortable') || lowerTitle.includes('soft') || lowerTitle.includes('smooth')) return '☁️';
    if (lowerTitle.includes('durable') || lowerTitle.includes('sturdy') || lowerTitle.includes('solid')) return '🛡️';
    if (lowerTitle.includes('design') || lowerTitle.includes('beautiful') || lowerTitle.includes('stylish')) return '🎨';
    
    return '💭';
  }
}
