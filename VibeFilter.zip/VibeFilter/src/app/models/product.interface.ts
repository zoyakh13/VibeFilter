export interface Comment {
  comment: string;
  rating: number;
  short_title: string;
  mood: string;
  user?: string;
  date?: string;
}

export interface Product {
  product_title: string;
  short_description: string;
  image: string;
  rating: number;
  comments: Comment[];
}

export interface MoodEmoji {
  [key: string]: string;
}
